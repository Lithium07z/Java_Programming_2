package w12TestPack1;

class Student {
	private int number;
	private String name;
	public Student(int number, String name) {
		this.number = number;
		this.name = name;
	}
	public String toString() {
		return name;
	}
}
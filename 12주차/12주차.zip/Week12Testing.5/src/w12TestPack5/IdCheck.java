package w12TestPack5;

public class IdCheck {
	public static void main(String[] args) {
		CheckingIdType.inputId();			
	}
}
